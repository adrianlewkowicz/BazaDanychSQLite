package com.example.bazydanychsqllite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.EditText;
import android.database.Cursor;
import android.widget.TextView;
import android.text.method.ScrollingMovementMethod;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MyDatabase mydb = new MyDatabase(this);

        EditText etNumber, etName;
        etNumber = (EditText) findViewById(R.id.etNumber);
        etName = (EditText) findViewById(R.id.etName);

        String strNumber = etNumber.getText().toString();
        String strName = etName.getText().toString();
        mydb.AddStudent(strNumber, strName);


        TextView tv = (TextView)findViewById(R.id.textView1);

        tv.setText("Lista Studentów");
        Cursor c = mydb.getStudents();
        while (c.moveToNext()){
            tv.append("\n" + c.getString(0) + " " + c.getString(1) + " " + c.getString(2) + " " + c.getString(3));
            tv.setMovementMethod(ScrollingMovementMethod.getInstance());

        }

        mydb.executeSQL(
                "insert into students(Name, Surname, IndexNumber) values('John','Smith','GB23423');"
        );
    }

    


}
