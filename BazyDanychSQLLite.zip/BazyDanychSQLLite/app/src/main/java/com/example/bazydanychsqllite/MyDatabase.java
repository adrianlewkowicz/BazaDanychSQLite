package com.example.bazydanychsqllite;
import android.content.ContentValues;
import android.database.Cursor;
import  android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;

public class MyDatabase extends SQLiteOpenHelper{
    public MyDatabase (Context context)
    {
        super(context,"students.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL(
                "create table students("
                + "StudentId integer primary key autoincrement"
                + ", Name text"
                + ", Surname text"
                + ", IndexNumber text"
                + ");"
        );
    };

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {

    };

    public void AddStudent(String Name, String Surname, String IndexNumber){
        SQLiteDatabase db =  getWritableDatabase();
        ContentValues student = new ContentValues();
        student.put("Name", Name);
        student.put("Surname", Surname);
        student.put("IndexNumber", IndexNumber);
        //db.insertOrThrow("students", null, student);
        db.insert("students", null,student);
    }

    public Cursor getStudents(){
        String[] collumns = {"StudentId","Name","Surname","IndexNumber"};
        SQLiteDatabase db = getReadableDatabase();

        Cursor records = db.query("students", collumns, null, null, null,null, null);
        return records;
    }

    public void AddStudent(String strNumber, String strName) {
    }

    public void executeSQL(String query){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL(query);

    }
}
